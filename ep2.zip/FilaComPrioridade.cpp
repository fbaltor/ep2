#include "FilaComPrioridade.h"
#include "Datagrama.h"

FilaComPrioridade::FilaComPrioridade(int tamanho) : Fila(tamanho) {}
FilaComPrioridade::~FilaComPrioridade() {}

void FilaComPrioridade::enqueue(Datagrama *d, bool prioritario) {}
